// /home/ubuntu/christian_journal_app/mobile_app/src/components/JournalEntryForm.js
import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView } from "react-native";
import axios from "axios";

// Define backend URL (consistent with screens)
const API_URL = "http://10.0.2.2:5000";

// Placeholder for voice recording functionality - requires additional libraries like react-native-voice or expo-av
// For now, we'll just include the text form.

function JournalEntryForm({ onNewEntry }) {
    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");
    const [tags, setTags] = useState(""); // Simple comma-separated tags
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleTextSubmit = async () => {
        if (!content.trim()) {
            setError("Content cannot be empty.");
            return;
        }
        setError("");
        setLoading(true);
        try {
            // Need to handle authentication (e.g., send token/cookie)
            const entryData = {
                title: title || "Untitled Entry",
                content,
                tags: tags.split(",").map(t => t.trim()).filter(t => t)
            };
            const response = await axios.post(`${API_URL}/entries`, entryData);
            console.log("Entry created:", response.data);
            if (onNewEntry) {
                onNewEntry(response.data); // Notify parent component (e.g., JournalScreen)
            }
            // Clear form
            setTitle("");
            setContent("");
            setTags("");
            Alert.alert("Success", "Journal entry saved.");
        } catch (err) {
            console.error("Error creating entry:", err.response ? err.response.data : err.message);
            const errorMessage = err.response?.data?.error || "Failed to save entry.";
            setError(errorMessage);
            Alert.alert("Error", errorMessage);
        } finally {
            setLoading(false);
        }
    };

    // Add voice recording functions (startRecording, stopRecording, transcribeAudio) later
    // using appropriate React Native libraries.

    return (
        <ScrollView style={styles.formContainer}>
            <Text style={styles.formTitle}>Create New Journal Entry</Text>
            {error ? <Text style={styles.errorText}>{error}</Text> : null}
            
            <Text style={styles.label}>Title (Optional):</Text>
            <TextInput
                style={styles.input}
                value={title}
                onChangeText={setTitle}
                placeholder="Entry Title"
            />
            
            <Text style={styles.label}>Content:</Text>
            <TextInput
                style={[styles.input, styles.textArea]}
                value={content}
                onChangeText={setContent}
                placeholder="Write your thoughts..."
                multiline
                required
            />

            <Text style={styles.label}>Tags (Optional, comma-separated):</Text>
            <TextInput
                style={styles.input}
                value={tags}
                onChangeText={setTags}
                placeholder="e.g., faith, prayer, gratitude"
            />

            <Button 
                title={loading ? "Saving..." : "Save Entry"} 
                onPress={handleTextSubmit} 
                disabled={loading} 
            />

            {/* Placeholder for Voice Input Button */}
            {/* <Button title="Record Voice (Coming Soon)" onPress={() => Alert.alert("Feature Not Implemented", "Voice recording will be added later.")} /> */}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    formContainer: {
        padding: 10, // Add padding around the form
        marginBottom: 10, // Space below the form
    },
    formTitle: {
        fontSize: 20,
        fontWeight: "bold",
        marginBottom: 15,
        textAlign: "center",
    },
    label: {
        fontSize: 16,
        marginBottom: 5,
        marginLeft: 5, // Align with input padding
    },
    input: {
        height: 40,
        borderColor: "gray",
        borderWidth: 1,
        marginBottom: 12,
        paddingHorizontal: 10,
        backgroundColor: "#fff", // White background for inputs
        borderRadius: 5,
    },
    textArea: {
        height: 100, // Taller for multiline input
        textAlignVertical: "top", // Start text from the top
    },
    errorText: {
        color: "red",
        marginBottom: 10,
        textAlign: "center",
    },
});

export default JournalEntryForm;

