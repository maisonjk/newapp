// /home/ubuntu/christian_journal_app/mobile_app/src/components/LegacyEntryForm.js
import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView } from "react-native";
import axios from "axios";

// Define backend URL (consistent with screens)
const API_URL = "http://10.0.2.2:5000";

function LegacyEntryForm({ onNewLegacyEntry }) {
    const [title, setTitle] = useState("");
    const [message, setMessage] = useState("");
    const [recipient, setRecipient] = useState("Future Generations");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSubmit = async () => {
        if (!message.trim()) {
            setError("Message cannot be empty.");
            return;
        }
        setError("");
        setLoading(true);
        try {
            // Need to handle authentication
            const response = await axios.post(`${API_URL}/legacy_entries`, {
                title: title || "Legacy Message", // Default title if empty
                message,
                recipient,
                // media: [] // Placeholder for future media uploads
            });
            console.log("Legacy entry created:", response.data);
            if (onNewLegacyEntry) {
                onNewLegacyEntry(response.data); // Notify parent component
            }
            // Clear form
            setTitle("");
            setMessage("");
            setRecipient("Future Generations");
            Alert.alert("Success", "Legacy message saved.");
        } catch (err) {
            console.error("Error creating legacy entry:", err.response ? err.response.data : err.message);
            const errorMessage = err.response?.data?.error || "Failed to save legacy message.";
            setError(errorMessage);
            Alert.alert("Error", errorMessage);
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScrollView style={styles.formContainer}>
            <Text style={styles.formTitle}>Create New Legacy Message</Text>
            {error ? <Text style={styles.errorText}>{error}</Text> : null}
            
            <Text style={styles.label}>Title (Optional):</Text>
            <TextInput
                style={styles.input}
                value={title}
                onChangeText={setTitle}
                placeholder="Message Title"
            />

            <Text style={styles.label}>Recipient (Optional):</Text>
            <TextInput
                style={styles.input}
                value={recipient}
                onChangeText={setRecipient}
                placeholder="e.g., My Children, Future Self"
            />

            <Text style={styles.label}>Message:</Text>
            <TextInput
                style={[styles.input, styles.textArea]}
                value={message}
                onChangeText={setMessage}
                placeholder="Write your legacy message..."
                multiline
                required
            />
            
            {/* Add media upload button here later */}
            <Button 
                title={loading ? "Saving..." : "Save Legacy Message"} 
                onPress={handleSubmit} 
                disabled={loading} 
            />
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    formContainer: {
        padding: 10,
        marginBottom: 10,
    },
    formTitle: {
        fontSize: 20,
        fontWeight: "bold",
        marginBottom: 15,
        textAlign: "center",
    },
    label: {
        fontSize: 16,
        marginBottom: 5,
        marginLeft: 5,
    },
    input: {
        height: 40,
        borderColor: "gray",
        borderWidth: 1,
        marginBottom: 12,
        paddingHorizontal: 10,
        backgroundColor: "#fff",
        borderRadius: 5,
    },
    textArea: {
        height: 120, // Taller for legacy message
        textAlignVertical: "top",
    },
    errorText: {
        color: "red",
        marginBottom: 10,
        textAlign: "center",
    },
});

export default LegacyEntryForm;

