// /home/ubuntu/christian_journal_app/mobile_app/src/components/JournalList.js
import React, { useState, useEffect, useCallback } from "react";
import { View, Text, FlatList, StyleSheet, ActivityIndicator, RefreshControl } from "react-native";
import axios from "axios";

// Define backend URL (consistent with screens)
const API_URL = "http://10.0.2.2:5000";

function JournalList() {
    const [entries, setEntries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [refreshing, setRefreshing] = useState(false);

    const fetchEntries = useCallback(async () => {
        setError("");
        try {
            // Need to handle authentication (e.g., send token/cookie)
            // For now, assuming backend doesn't strictly enforce login for GET /entries
            // In a real app, axios interceptors or default headers would manage auth
            const response = await axios.get(`${API_URL}/entries`);
            setEntries(response.data);
        } catch (err) {
            console.error("Error fetching entries:", err.response ? err.response.data : err.message);
            setError("Failed to load journal entries.");
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useEffect(() => {
        setLoading(true);
        fetchEntries();
    }, [fetchEntries]);

    const onRefresh = useCallback(() => {
        setRefreshing(true);
        fetchEntries();
    }, [fetchEntries]);

    const renderItem = ({ item }) => (
        <View style={styles.entryItem}>
            <Text style={styles.entryTitle}>{item.title || "Untitled Entry"}</Text>
            <Text style={styles.entryDate}>{new Date(item.timestamp).toLocaleString()}</Text>
            <Text>{item.content.substring(0, 100)}{item.content.length > 100 ? "..." : ""}</Text>
            {/* Add touchable opacity for navigation to detail view later */}
        </View>
    );

    if (loading && !refreshing) {
        return <ActivityIndicator size="large" style={styles.loader} />;
    }

    if (error) {
        return <Text style={styles.errorText}>{error}</Text>;
    }

    return (
        <FlatList
            data={entries}
            renderItem={renderItem}
            keyExtractor={(item) => item.id.toString()} // Ensure key is a string
            ListEmptyComponent={<Text style={styles.emptyText}>No entries yet. Start writing!</Text>}
            refreshControl={
                <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
            }
            style={styles.list}
        />
    );
}

const styles = StyleSheet.create({
    list: {
        flex: 1, // Ensure FlatList takes up available space
    },
    loader: {
        marginTop: 20,
    },
    errorText: {
        color: "red",
        textAlign: "center",
        marginTop: 20,
    },
    emptyText: {
        textAlign: "center",
        marginTop: 20,
        fontSize: 16,
        color: "gray",
    },
    entryItem: {
        backgroundColor: "#fff",
        padding: 15,
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: "#eee",
    },
    entryTitle: {
        fontSize: 18,
        fontWeight: "bold",
    },
    entryDate: {
        fontSize: 12,
        color: "gray",
        marginBottom: 5,
    },
});

export default JournalList;

