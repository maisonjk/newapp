// /home/ubuntu/christian_journal_app/mobile_app/src/components/LegacyList.js
import React, { useState, useEffect, useCallback } from "react";
import { View, Text, FlatList, StyleSheet, ActivityIndicator, RefreshControl } from "react-native";
import axios from "axios";

// Define backend URL (consistent with screens)
const API_URL = "http://10.0.2.2:5000";

function LegacyList() {
    const [legacyEntries, setLegacyEntries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [refreshing, setRefreshing] = useState(false);

    const fetchLegacyEntries = useCallback(async () => {
        setError("");
        try {
            // Need to handle authentication
            const response = await axios.get(`${API_URL}/legacy_entries`);
            setLegacyEntries(response.data);
        } catch (err) {
            console.error("Error fetching legacy entries:", err.response ? err.response.data : err.message);
            setError("Failed to load legacy messages.");
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useEffect(() => {
        setLoading(true);
        fetchLegacyEntries();
    }, [fetchLegacyEntries]);

    const onRefresh = useCallback(() => {
        setRefreshing(true);
        fetchLegacyEntries();
    }, [fetchLegacyEntries]);

    const renderItem = ({ item }) => (
        <View style={styles.entryItem}>
            <Text style={styles.entryTitle}>{item.title}</Text>
            <Text style={styles.entryRecipient}>For: {item.recipient}</Text>
            <Text style={styles.entryDate}>Saved: {new Date(item.timestamp).toLocaleString()}</Text>
            <Text>{item.message}</Text>
            {/* Add touchable opacity for navigation/options later */}
        </View>
    );

    if (loading && !refreshing) {
        return <ActivityIndicator size="large" style={styles.loader} />;
    }

    if (error) {
        return <Text style={styles.errorText}>{error}</Text>;
    }

    return (
        <FlatList
            data={legacyEntries}
            renderItem={renderItem}
            keyExtractor={(item) => item.id.toString()} // Ensure key is a string
            ListEmptyComponent={<Text style={styles.emptyText}>No legacy messages saved yet.</Text>}
            refreshControl={
                <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
            }
            style={styles.list}
        />
    );
}

const styles = StyleSheet.create({
    list: {
        flex: 1,
    },
    loader: {
        marginTop: 20,
    },
    errorText: {
        color: "red",
        textAlign: "center",
        marginTop: 20,
    },
    emptyText: {
        textAlign: "center",
        marginTop: 20,
        fontSize: 16,
        color: "gray",
    },
    entryItem: {
        backgroundColor: "#fff",
        padding: 15,
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: "#eee",
    },
    entryTitle: {
        fontSize: 18,
        fontWeight: "bold",
    },
    entryRecipient: {
        fontSize: 14,
        fontStyle: "italic",
        color: "#444",
        marginBottom: 5,
    },
    entryDate: {
        fontSize: 12,
        color: "gray",
        marginBottom: 5,
    },
});

export default LegacyList;

