// /home/ubuntu/christian_journal_app/mobile_app/src/components/BibleLookup.js
import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, ActivityIndicator, ScrollView, Alert, Picker } from "react-native"; // Added Picker
import axios from "axios";

// Define backend URL (consistent with screens)
const API_URL = "http://10.0.2.2:5000";

function BibleLookup() {
    const [reference, setReference] = useState("John 3:16");
    const [translation, setTranslation] = useState("web"); // Default to World English Bible
    const [scripture, setScripture] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleLookup = async () => {
        if (!reference.trim()) {
            setError("Please enter a Bible reference.");
            return;
        }
        setLoading(true);
        setError("");
        setScripture(null);
        try {
            // Encode the reference to handle spaces and special characters in URL path
            const encodedReference = encodeURIComponent(reference);
            // Need to handle authentication if backend requires it
            const response = await axios.get(`${API_URL}/bible/${encodedReference}?translation=${translation}`);
            setScripture(response.data);
        } catch (err) {
            console.error("Error fetching scripture:", err.response ? err.response.data : err.message);
            const errorMessage = err.response?.data?.error || "Failed to fetch scripture. Check reference/translation.";
            setError(errorMessage);
            Alert.alert("Lookup Failed", errorMessage);
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScrollView style={styles.container}> 
            <Text style={styles.title}>Bible Lookup</Text>
            
            <Text style={styles.label}>Reference (e.g., John 3:16):</Text>
            <TextInput
                style={styles.input}
                value={reference}
                onChangeText={setReference}
                placeholder="Enter Bible Reference"
                required
            />

            <Text style={styles.label}>Translation:</Text>
            {/* Use Picker for selecting translation */}
            <View style={styles.pickerContainer}>
                <Picker
                    selectedValue={translation}
                    style={styles.picker}
                    onValueChange={(itemValue, itemIndex) => setTranslation(itemValue)}
                >
                    <Picker.Item label="WEB (World English Bible)" value="web" />
                    <Picker.Item label="KJV (King James Version)" value="kjv" />
                    <Picker.Item label="BBE (Bible in Basic English)" value="bbe" />
                    {/* Add other translations supported by bible-api.com if needed */}
                </Picker>
            </View>

            <Button title={loading ? "Looking up..." : "Lookup Scripture"} onPress={handleLookup} disabled={loading} />

            {loading && <ActivityIndicator size="large" style={styles.loader} />}
            {error && !loading && <Text style={styles.errorText}>{error}</Text>}

            {scripture && !loading && (
                <View style={styles.scriptureContainer}>
                    <Text style={styles.scriptureReference}>{scripture.reference} ({scripture.translation_name})</Text>
                    {scripture.verses.map((verse) => (
                        <Text key={verse.verse} style={styles.verseText}>
                            <Text style={styles.verseNumber}>{verse.chapter}:{verse.verse}</Text> {verse.text}
                        </Text>
                    ))}
                </View>
            )}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 15,
    },
    title: {
        fontSize: 22,
        fontWeight: "bold",
        marginBottom: 15,
        textAlign: "center",
    },
    label: {
        fontSize: 16,
        marginBottom: 5,
        marginLeft: 5,
    },
    input: {
        height: 40,
        borderColor: "gray",
        borderWidth: 1,
        marginBottom: 12,
        paddingHorizontal: 10,
        backgroundColor: "#fff",
        borderRadius: 5,
    },
    pickerContainer: {
        borderColor: "gray",
        borderWidth: 1,
        borderRadius: 5,
        marginBottom: 15,
        backgroundColor: "#fff",
    },
    picker: {
        height: 50, 
        width: "100%",
    },
    loader: {
        marginTop: 20,
    },
    errorText: {
        color: "red",
        marginTop: 15,
        textAlign: "center",
    },
    scriptureContainer: {
        marginTop: 20,
        padding: 15,
        backgroundColor: "#f9f9f9",
        borderRadius: 5,
        borderWidth: 1,
        borderColor: "#eee",
    },
    scriptureReference: {
        fontSize: 18,
        fontWeight: "bold",
        marginBottom: 10,
        textAlign: "center",
    },
    verseText: {
        fontSize: 16,
        marginBottom: 8,
        lineHeight: 22, // Improve readability
    },
    verseNumber: {
        fontWeight: "bold",
        color: "#555",
    },
});

export default BibleLookup;

