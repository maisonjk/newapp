// /home/ubuntu/christian_journal_app/mobile_app/App.js
import React, { useState, useEffect, useCallback } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { View, Text, Button, ActivityIndicator, StyleSheet, ScrollView } from "react-native";
import axios from "axios";
import LoginScreen from "./src/screens/LoginScreen";
import RegisterScreen from "./src/screens/RegisterScreen";
import JournalList from "./src/components/JournalList";
import JournalEntryForm from "./src/components/JournalEntryForm";
import BibleLookup from "./src/components/BibleLookup"; // Import BibleLookup
import LegacyList from "./src/components/LegacyList"; // Import LegacyList
import LegacyEntryForm from "./src/components/LegacyEntryForm"; // Import LegacyEntryForm

// Define backend URL (consistent with screens)
const API_URL = "http://10.0.2.2:5000";

// --- Tab Screens (Updated) ---
function JournalScreen() {
  const [refreshKey, setRefreshKey] = useState(0);
  const handleNewEntry = () => {
      setRefreshKey(prevKey => prevKey + 1);
  };
  return (
    <ScrollView style={styles.screenContainer}>
      <JournalEntryForm onNewEntry={handleNewEntry} />
      <JournalList key={refreshKey} />
    </ScrollView>
  );
}

function BibleScreen() {
  // BibleLookup component handles its own scrolling
  return (
    <View style={styles.screenContainerPadded}> 
      <BibleLookup />
    </View>
  );
}

function LegacyScreen() {
  const [refreshKey, setRefreshKey] = useState(0);
  const handleNewLegacyEntry = () => {
      setRefreshKey(prevKey => prevKey + 1);
  };
  return (
    <ScrollView style={styles.screenContainer}>
      <LegacyEntryForm onNewLegacyEntry={handleNewLegacyEntry} />
      <LegacyList key={refreshKey} />
    </ScrollView>
  );
}

function SettingsScreen({ onLogout }) {
  return (
    <View style={styles.settingsContainer}> 
      <Text style={styles.settingsTitle}>Settings</Text>
      {/* Add other settings options here later */}
      <Button title="Logout" onPress={onLogout} />
    </View>
  );
}

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Tab Navigator for the main app sections after login
function MainAppTabs({ onLogout }) {
  return (
    <Tab.Navigator screenOptions={{ headerShown: true }}>
      <Tab.Screen name="Journal" component={JournalScreen} />
      <Tab.Screen name="Bible" component={BibleScreen} />
      <Tab.Screen name="Legacy" component={LegacyScreen} />
      <Tab.Screen name="Settings">
        {(props) => <SettingsScreen {...props} onLogout={onLogout} />}
      </Tab.Screen>
    </Tab.Navigator>
  );
}

// Main App component managing auth state and navigation
function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const checkLoggedIn = useCallback(async () => {
    setLoading(true);
    // Simulate check - replace with AsyncStorage/SecureStore later
    setCurrentUser(null); // Default to logged out
    setLoading(false);
  }, []);

  useEffect(() => {
    checkLoggedIn();
  }, [checkLoggedIn]);

  const handleLoginSuccess = (userData) => {
    console.log("Setting current user:", userData);
    setCurrentUser(userData);
    // Persist login state here (e.g., AsyncStorage)
  };

  const handleLogout = async () => {
    setLoading(true);
    try {
      // await axios.post(`${API_URL}/logout`); // Needs cookie/token handling
      console.log("Logging out");
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      setCurrentUser(null);
      // Clear persisted login state here
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator>
        {currentUser ? (
          <Stack.Screen 
            name="MainApp"
            options={{ headerShown: false }} // Hide Stack header for Tabs
          >
            {(props) => <MainAppTabs {...props} onLogout={handleLogout} />}
          </Stack.Screen>
        ) : (
          <>
            <Stack.Screen 
              name="Login" 
              options={{ title: "Login" }} 
            >
              {(props) => (
                <LoginScreen {...props} onLoginSuccess={handleLoginSuccess} />
              )}
            </Stack.Screen>
            <Stack.Screen 
              name="Register" 
              options={{ title: "Register" }} 
            >
              {(props) => (
                <RegisterScreen {...props} onLoginSuccess={handleLoginSuccess} />
              )}
            </Stack.Screen>
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  screenContainer: {
    flex: 1,
    backgroundColor: "#f0f0f0", // Light background for screens with scrolling forms
  },
   screenContainerPadded: { // Added for screens without their own ScrollView
    flex: 1,
    backgroundColor: "#f0f0f0",
    padding: 15, // Add padding directly here
  },
  settingsContainer: { // Specific style for settings screen
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  settingsTitle: {
      fontSize: 22,
      fontWeight: "bold",
      marginBottom: 20,
  }
});

export default App;

